import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
public class UserDAO 
{
    int deleted=1;
	List<User> getInActiveUsers() throws Exception
	{
	List<User> list = new ArrayList<>();
		Statement stmt = DbConnection.getConnection().createStatement();
		ResultSet rs = stmt.executeQuery("select * from user where deleted="+deleted+" order by username asc");
		while (rs.next()) {
			User us = new User();
			us.setId(rs.getInt(1));
			us.setUsername(rs.getString(2));
			us.setAddress(rs.getString(3));
			us.setMobileNumber(rs.getString(4));
			list.add(us);
		}
		return list;	
	}
	public void makeInActive(int failedAttempts) throws Exception
	{
		Statement stmt = DbConnection.getConnection().createStatement();
		stmt.execute("update user set deleted =1 where failedattempts>" + failedAttempts);
	}
}
