import java.util.List;
import java.util.Scanner;

public class Main 
{
public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of login attempts");
		int n = sc.nextInt();

		UserDAO d = new UserDAO();
		d.makeInActive(n);
		System.out.println("Inactive user Details :");
		System.out.println("Name Address Mobile Number");
		List<User> list = d.getInActiveUsers();
		for (User user : list) {
			System.out.println(user);
		}
	}
}
