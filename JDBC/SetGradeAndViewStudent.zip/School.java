import java.sql.ResultSet;
import java.sql.Statement;

public class School
{
	public Student viewStudent(int sid) throws Exception
	{
		Student s = new Student();
		DB d = new DB();
		Statement stmt = d.getConnection().createStatement();
		ResultSet rs = stmt.executeQuery("select * from student where studId =" + sid);
		while (rs.next()) {
			s.setStudId(rs.getInt(1));
			s.setStudName(rs.getString(2));
			s.setTotal(rs.getInt(3));
		}
	return s;
	}
}
