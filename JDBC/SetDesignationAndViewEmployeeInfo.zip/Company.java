import java.sql.ResultSet;
import java.sql.Statement;

public class Company {
	public Employee viewEmployee(int eid) throws Exception
	{
	    //fill the logic to retrieve the employee details from the employee data base and return employee object
		Employee e = new Employee();
		DB d = new DB();
		Statement stmt = d.getConnection().createStatement();
		ResultSet rs = stmt.executeQuery("select * from employee where empid =" + eid);
		while (rs.next()) {
			e.setEmpId(rs.getInt(1));
			e.setEmpName(rs.getString(2));
			e.setExperience(rs.getInt(3));
		}

		return e;
	}
}
